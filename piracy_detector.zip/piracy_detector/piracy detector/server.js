const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
const cors = require('cors');
app.use(cors());

const PORT = process.env.PORT || 3001;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Route to handle keyword search
app.post('/search', async (req, res) => {
    const { url, keyword } = req.body;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (data.includes(keyword)) {
            res.json({ found: true, message: 'Potential piracy detected!', url });
        } else {
            res.json({ found: false, message: 'No piracy detected.', url });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error fetching the URL.' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
