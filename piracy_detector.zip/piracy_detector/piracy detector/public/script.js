document.getElementById('check-btn').addEventListener('click', async () => {
    const url = document.getElementById('url').value.trim();
    const title = document.getElementById('title').value.trim();

    // Input validation
    if (!url || !title) {
        document.getElementById('result').textContent = 'Please enter both URL and keyword.';
        document.getElementById('result').style.color = 'black';
        return;
    }

    // Display loading message
    document.getElementById('result').textContent = 'Searching...';
    document.getElementById('result').style.color = 'black';

    try {
        const response = await fetch('/check', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url, title }),
        });

        const result = await response.json();

        if (result.found) {
            document.getElementById('result').textContent = `${result.message} URL: ${result.url}`;
            document.getElementById('result').style.color = 'red';
        } else {
            document.getElementById('result').textContent = result.message;
            document.getElementById('result').style.color = 'green';
        }
    } catch (error) {
        document.getElementById('result').textContent = 'An error occurred during the checking.';
        document.getElementById('result').style.color = 'black';
        console.error(error);
    }
});
